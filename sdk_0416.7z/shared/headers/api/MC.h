﻿#pragma once
#include<mcapi/Core.h>
#include<mcapi/Player.h>
#include<mcapi/Level.h>
#include<mcapi/BlockSource.h>
#include<mcapi/Dimension.h>
#include<mcapi/Block.h>
#include<mcapi/Item.h>
#include<mcapi/Actor.h>
#include<mcapi/Command/Command.h>
#include<mcapi/VanillaBlocks.h>