﻿#ifndef  ALL_H
#define ALL_H
#include"api_pch.h"
#include"stl_pch.h"
#define do_log wprintf
#define do_dbg_log wprintf
#endif