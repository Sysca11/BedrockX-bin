event.Filter("LCMD","invchk",true,function(name,a)
		if isOP(name)==false then
			sendText(name,"op only")
			return false
		end
		local a,b=invapi.dumpInv(a,0),invapi.dumpInv(a,1)
		print(a,b)
		sendText(name,a)
		sendText(name,b)
		return false
	end
)
fs.mkdir("invdump")
Listen("onJoin",function(name)
	local a,b=invapi.dumpInv(name,0),invapi.dumpInv(name,1)
	local f=io.open(string.format("invdump/%s.txt",name),"w")
	f:write(a,"\n",b)
	f:close()
end)
