local b64=require("base64")
fs.mkdir("chests")
local PATH="chests/%s.dump"
event.Filter("CMD","pushc",true,function(name)
		local fn=string.format(PATH,b64.encode(name))
		invapi.MoveEnderChestTo(name,fn)
		sendText(name,"done")
		return false
	end
)
event.Filter("CMD","popc",true,function(name)
		local fn=string.format(PATH,b64.encode(name))
		if fs.exists(fn) then
			invapi.LoadEnderChestFrom(name,fn)
			fs.del(fn)
			sendText(name,"done")
		else
			sendText(name,"cant find")
		end
		return false
	end
)
